// SERVICIOS
miAplicacion.service('ServicioSucursales', function ($http) {

    this.traerTodo = function () {
      return $http.get('../ws/sucursales').then(function(respuesta) {    
         return respuesta.data.listado;    
      });
    }

    this.Agregar = function(dato){
      return $http.post('../ws/sucursal/'+dato).then(function(respuesta){
        return respuesta.data;
      })
    }

    this.Modificar = function(dato){
      return $http.put('../ws/sucursal/'+dato).then(function(respuesta){
        console.log(respuesta);
        return respuesta.data;
      }) 
    }

    this.Detallar = function(dato){
      return $http.get('../ws/sucursal/'+dato).then(function(respuesta){
        return respuesta.data;
      }) 
    }
    
    this.Borrar = function(dato){
      return $http.delete('../ws/sucursal/'+dato).then(function(respuesta){
        return respuesta.data;
      }) 
    }
  })