// SERVICIOS

miAplicacion.service('ServicioPersonas', function ($http) {

    this.traerTodo = function () {
      return $http.get('../ws/usuarios').then(function(respuesta) {      
         return respuesta.data.listado;    
      });
    }

    this.Agregar = function(dato){
      return $http.post('../ws/usuario/'+dato).then(function(respuesta){
        return respuesta.data;
      })
    }

    this.Modificar = function(dato){
      return $http.put('../ws/usuario/'+dato).then(function(respuesta){
        return respuesta.data;
      }) 
    }

    this.Detallar = function(dato){
      return $http.get('../ws/usuario/'+dato).then(function(respuesta){
        return respuesta.data;
      }) 
    }

    this.Borrar = function(dato){
      return $http.delete('../ws/usuario/'+dato).then(function(respuesta){
        return respuesta.data;
      }) 
    }

  })