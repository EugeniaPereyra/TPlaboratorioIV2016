// SERVICIOS
miAplicacion.service('ServicioOfertas', function ($http) {

    this.traerTodo = function () {
      return $http.get('../ws/ofertas').then(function(respuesta) {    
         return respuesta.data.listado;    
      });
    }

    this.Agregar = function(dato){
      return $http.post('../ws/oferta/'+dato).then(function(respuesta){
        return respuesta.data;
      })
    }

    this.Modificar = function(dato){
      return $http.put('../ws/oferta/'+dato).then(function(respuesta){
        console.log(respuesta);
        return respuesta.data;
      }) 
    }

    this.Detallar = function(dato){
      return $http.get('../ws/oferta/'+dato).then(function(respuesta){
        return respuesta.data;
      }) 
    }
    
    this.Borrar = function(dato){
      return $http.delete('../ws/oferta/'+dato).then(function(respuesta){
        return respuesta.data;
      }) 
    }
  })