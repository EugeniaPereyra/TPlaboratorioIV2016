// SERVICIOS
miAplicacion.service('ServicioEncuestas', function ($http) {

    this.traerTodo = function () {
      return $http.get('../ws/encuestas').then(function(respuesta) {    
         return respuesta.data.listado;    
      });
    }

    this.Agregar = function(dato){
      return $http.post('../ws/encuesta/'+dato).then(function(respuesta){
        return respuesta.data;
      })
    }

    this.Detallar = function(dato){
      return $http.get('../ws/encuesta/'+dato).then(function(respuesta){
        return respuesta.data;
      }) 
    }
    
    this.Borrar = function(dato){
      return $http.delete('../ws/encuesta/'+dato).then(function(respuesta){
        return respuesta.data;
      }) 
    }
  })